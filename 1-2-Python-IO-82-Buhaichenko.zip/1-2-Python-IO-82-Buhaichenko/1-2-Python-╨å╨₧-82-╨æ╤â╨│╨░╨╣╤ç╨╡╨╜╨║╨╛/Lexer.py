from Token import Token


class TheToken():
    keyword = ['def', 'main', 'return']
    symbol = ['(', ')', ':']
    spec_symbol = ['\'', '\"']
    spaces = [' ', '\n', '\\R', '\\']
    bin_sym = ['b', '0', '1']
    digits = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']

    def __init__(self, code):

        self.code = code

    def reader(self, code):
        ind = 0
        token_list = []
        size = len(code)

        while ind < size:
            if code[ind] in self.spaces:
                ind += 1
            elif code[ind] in self.symbol:
                token = Token("spec_symbol", code[ind])
                token_list.append(token)
                ind += 1
            elif code[ind:ind+3] in self.keyword and code[ind:ind+3] == self.keyword[0]:
                token = Token('keyword', code[ind:ind+3])
                token_list.append(token)
                ind += 3
            elif code[ind:ind+4] in self.keyword and code[ind:ind+4] == self.keyword[1]:
                token = Token('keyword', code[ind:ind+4])
                token_list.append(token)
                ind += 4
            elif code[ind:ind+6] in self.keyword and code[ind:ind+6] == self.keyword[2]:
                token = Token('keyword', code[ind:ind+6])
                token_list.append(token)
                ind += 6
                try:
                    while code[ind] == ' ':
                        ind += 1
                    if code[ind] in self.digits:
                        ind2 = ind
                        while (ind2 < len(code)-1):
                            if code[ind2].isdigit or (code[ind2] in self.bin_sym):
                                ind2 += 1
                        token = Token("number", code[ind:ind2+1])
                        token_list.append(token)
                        ind += len(code[ind:ind2+1])
                    elif code[ind] in self.spec_symbol:
                        token = Token("spec_symbol", code[ind])
                        token_list.append(token)
                        ind2 = ind

                        while code[ind+1] not in self.spec_symbol:
                            ind2 += 1
                        size_of_string = ind2 - ind
                        ind += 1
                        token = Token("str", code[ind:ind + size_of_string])
                        token_list.append(token)
                        ind += size_of_string
                        token = Token("spec_symbol", code[ind])
                        token_list.append(token)
                except IndexError:
                    print("syntax error")
                ind += 1
        return token_list

