from Lexer import TheToken
from Parser import program
import sys

with open("1-2-Python-IО-82-Бугайченко.asm", "w") as file:
    sys.stdout = file
    with open("1-2-Python-IО-82-Бугайченко.txt", "r") as in_put:
        code = in_put.read()
        c = TheToken(code)
        #shit = str(c.reader(code))
        #print(shit)

        code_input = program(c.reader(code))
        print(code_input)

"""from Lexer import TheToken
from Parser import program
import sys

with open("1-2-Python-IО-82-Бугайченко.asm", "w") as file:
    sys.stdout = file
    with open("1-2-Python-IО-82-Бугайченко.txt", "r") as in_put:
#code = "def main(): return 2"
        c = TheToken(code)
        shit = str(c.reader(code))
        print(shit)

        code_input = program(c.reader(code))
        print(code_input)"""