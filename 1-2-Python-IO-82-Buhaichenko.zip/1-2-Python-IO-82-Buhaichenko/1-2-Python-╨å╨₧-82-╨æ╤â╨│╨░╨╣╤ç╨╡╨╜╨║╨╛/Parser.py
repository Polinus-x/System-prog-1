import Lexer

def code_output(token_list, code):
    the_output = ".386\n" \
                 ".model flat, stdcall\n" \
                 "option casemap: none;\n" \
                 "include E:\masm32\include\windows.inc\n" \
                 "include E:\masm32\include\kernel32.inc\n" \
                 "include E:\masm32\include\\user32.inc\n" \
                 "include E:\masm32\include\\masm32rt.inc\n" \
                 "includelib E:\masm32\lib\kernel32.lib\n" \
                 "includelib E:\masm32\lib\\user32.lib\n" \
                 ".data\n" \
                 ".code\n" \
                 f"{token_list[1].value} proc\n{code}\nfn MessageBox,0,str$(eax),\"Buhaichenko\",MB_OK\n{token_list[1].value} ENDP\n" \
                 "start:\n" \
                 "invoke main\n" \
                 "invoke ExitProcess, 0\n" \
                 "end start\n"

    return the_output

def the_value(token):
    if token.value != '':
        value = f"mov eax,  {token.value} \nret"
    else:
        raise Exception("syntax error")
    return value


def program(token_list):
    ind = 0
    t1 = token_list[0].value
    t2 = token_list[1].value
    t3 = token_list[2].value
    t4 = token_list[3].value
    t5 = token_list[4].value
    t6 = token_list[5].value
    if (t1 == "def" and t2 == "main" and t3 == "(" and t4 == ")" and t5 == ":" and t6 == "return"):
        while token_list[ind].value != 'return':
            ind += 1
        ind += 1
        if token_list[ind].value in Lexer.TheToken.spec_symbol:
            code = the_value(token_list[ind+1])
            return code_output(token_list, code)
        else:
            code = the_value(token_list[ind])
            return code_output(token_list, code)
    else:
        return "syntax error"




